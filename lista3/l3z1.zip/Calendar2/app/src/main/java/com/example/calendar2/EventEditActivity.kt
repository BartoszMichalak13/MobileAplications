package com.example.calendar2

import android.app.TimePickerDialog
import android.app.TimePickerDialog.OnTimeSetListener
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalTime
import java.util.*
import android.app.*
import android.content.Context
import android.content.Intent
import com.example.calendar2.databinding.ActivityEventEditBinding

class EventEditActivity : AppCompatActivity() {

    private lateinit var binding : ActivityEventEditBinding //EventEditActivityBinding

    private var eventNameET: EditText? = null
    private var eventDateTV: TextView? = null
    private var eventTimeTV: Button? = null
    private var time: LocalTime? = null
    private var selectedEvent: Event? = null
    private var deleteButton: Button? = null
    var hour: Int = 0
    var minute: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEventEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //setContentView(R.layout.activity_event_edit)
        initWidgets()
        time = LocalTime.now()
        eventDateTV!!.text = "Date: " + CalenderUtils.formattedDate(CalenderUtils.selectedDate)
        eventTimeTV!!.text = "Time: " + CalenderUtils.formattedTime(time)
        checkForEditNote()
//        createNotificationChannel()
//        binding.submitcheck.setOnClickListener { scheduleNotification() }

    }

    private fun initWidgets() {
        eventNameET = binding.eventNameET//maybe change to fienf view
        eventDateTV = binding.eventDateTV
        eventTimeTV = binding.eventTimeTV
        deleteButton = binding.deleteButton
    }
//    private fun scheduleNotification()
//    {
//        println("KLIKU KLIK")
//        val intent = Intent(applicationContext, Notification::class.java)
//        val title = binding.titleET.text.toString()
//        val message = binding.messageET.text.toString()
//        intent.putExtra(titleExtra, title)
//        intent.putExtra(messageExtra, message)
//
//        val pendingIntent = PendingIntent.getBroadcast(
//            applicationContext,
//            notificationID,
//            intent,
//            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
//        )
//
//        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
//        val time = getTime()
//        alarmManager.setExactAndAllowWhileIdle(
//            AlarmManager.RTC_WAKEUP,
//            time,
//            pendingIntent
//        )
//        showAlert(time, title, message)
//    }
//    private fun showAlert(time: Long, title: String, message: String)
//    {
//        val date = Date(time)
//        val dateFormat = android.text.format.DateFormat.getLongDateFormat(applicationContext)
//        val timeFormat = android.text.format.DateFormat.getTimeFormat(applicationContext)
//
//        AlertDialog.Builder(this)
//            .setTitle("Notification Scheduled")
//            .setMessage(
//                "Title: " + title +
//                        "\nMessage: " + message +
//                        "\nAt: " + dateFormat.format(date) + " " + timeFormat.format(date))
//            .setPositiveButton("Okay"){_,_ ->}
//            .show()
//    }
//
//    private fun getTime(): Long
//    {
//        val minute = binding.timePicker.minute
//        val hour = binding.timePicker.hour
//        val day = binding.datePicker.dayOfMonth
//        val month = binding.datePicker.month
//        val year = binding.datePicker.year
//
//        val calendar = Calendar.getInstance()
//        calendar.set(year, month, day, hour, minute)
//        return calendar.timeInMillis
//    }
//
//    private fun createNotificationChannel()
//    {
//        val name = "Notif Channel"
//        val desc = "A Description of the Channel"
//        val importance = NotificationManager.IMPORTANCE_DEFAULT
//        val channel = NotificationChannel(channelID, name, importance)
//        channel.description = desc
//        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
//        notificationManager.createNotificationChannel(channel)
//    }

    fun popTimePicker(view: View?) {
        val onTimeSetListener =
            OnTimeSetListener { timePicker, selectedHour, selectedMinute ->
                hour = selectedHour
                minute = selectedMinute
                eventTimeTV?.text = java.lang.String.format(
                    Locale.getDefault(),
                    "%02d:%02d",
                    hour,
                    minute
                )
                time = LocalTime.parse(eventTimeTV?.text)
            }

        // int style = AlertDialog.THEME_HOLO_DARK;
        val timePickerDialog =
            TimePickerDialog(this,  /*style,*/onTimeSetListener, hour, minute, true)
        timePickerDialog.setTitle("Select Time")
        timePickerDialog.show()
    }
    private fun checkForEditNote() {
        val previousIntent = intent
        val passedNoteID: Int = previousIntent.getIntExtra(Event.EVENT_EDIT_EXTRA, -1)
        //println("In checkfor passedid $passedNoteID")
        selectedEvent = Event.getEventbyID(passedNoteID)
        if (selectedEvent != null) {
            eventNameET?.setText(selectedEvent!!.name)
            eventDateTV?.text = selectedEvent!!.date.toString()
            eventTimeTV?.text = selectedEvent!!.time.toString()
        } else {
            deleteButton?.visibility = View.INVISIBLE
        }
    }

    fun saveEventAction(view: View?) {
        val sqLiteManager = SQLiteManager.instanceOfDatabase(this)
        val name: String = eventNameET?.text.toString()
        if (selectedEvent == null) {
            val id: Int = Event.eventsList.size
            val newEvent = Event(id, name, CalenderUtils.selectedDate, time, false)
            Event.eventsList.add(newEvent)
            sqLiteManager?.addEventToDatabase(newEvent)
        } else {
            selectedEvent!!.name = name
            selectedEvent!!.date = CalenderUtils.selectedDate
            selectedEvent!!.time = time
            sqLiteManager!!.updateNoteInDB(selectedEvent!!)
        }
        finish()
    }
    fun deleteEventAction(view: View) {
        selectedEvent?.deleted = true
        val sqLiteManager = SQLiteManager.instanceOfDatabase(this)
        sqLiteManager!!.updateNoteInDB(selectedEvent!!)
        finish()
    }
}