package com.example.firework_project.model

class fireworkEveryFewClicksAction(val everyNclicks: Int) : Model.onPlayerClick {
    override fun checkForAction(player: Player, view: Model.fView?, yPos: Double, xPos: Double) {
       if(player.ClickCount%everyNclicks==0) {
           view?.fire(player.Color,yPos,xPos,player.fireworkSize, false)
       }
    }
}