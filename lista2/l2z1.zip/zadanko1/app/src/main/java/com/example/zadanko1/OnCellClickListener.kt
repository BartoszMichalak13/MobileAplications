package com.example.zadanko1

interface OnCellClickListener {
    fun onCellClick(cell: Cell)
}