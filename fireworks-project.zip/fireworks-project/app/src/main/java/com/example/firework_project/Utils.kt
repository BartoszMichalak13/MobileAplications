package com.example.firework_project

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.AssetFileDescriptor
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaPlayer
import android.os.Handler
import android.os.Message
import android.view.SurfaceHolder
import android.view.SurfaceView
import java.lang.Math.max
import kotlin.random.Random

enum class AnimateState {
    asReady, asRunning, asPause
}

/**
 * Rocket is the main class, which shows fireworks' particles
 * @param context - it is important for play explosion sound effect
 */
internal class Rocket(val a: Int, val b: Int, val g: Int, val context: Context?, val _x:Float, val _y:Float,
                      var red: Int, var green: Int, var blue: Int, val numberOfParticles: Int, val bigBoom: Boolean) {


    // TODO: Rename varialbes

    var sleep = true
    // explosion force
    private var energy = 0f
    // how long we can see particles (set in Fireworks: max 120 units)
    private var length = 0f
    private val mx: Float
    private val my: Float
    // it force particles to ground
    private var gravity: Float
    private var ox = _x
    private var oy = _y
    private var x = 0f
    private var y = 0f
    private var t = 0f
    private lateinit var vx: FloatArray
    private lateinit var vy: FloatArray

    // useful in further part of class
    private var random: Random? = null
    // used for single play sound effect, during creating particles
    var firstLaunch = true

    // mediaPlayer is sound player
    lateinit var mediaPlayer: MediaPlayer
    // fileDesc is kind of disc with music for mediaPlayer
    // it is sound's file in right format
    lateinit var fileDesc : AssetFileDescriptor


    init {
        mx = a.toFloat()
        my = b.toFloat()
        gravity = g.toFloat()
    }
    /**
     * @param e - energy
     * @param l - length, how long particles should be visible
     * @param seed - seed for random generator
     * @param context - help to find boom sound effect
     */
    fun init(e: Int, l: Int, seed: Long, context: Context?) {

        // setting up MediaPlayer
        mediaPlayer = MediaPlayer()
        if (context != null) {
            // finding sound in assets
            fileDesc = context.assets.openFd("boom2.mp3")
            // upload our sound to mediaPlayer
            mediaPlayer.setDataSource(fileDesc)
            // set mediaPlayer to async mode
            mediaPlayer.prepareAsync()
        }
        // initiate new Rocket, so firstLaunch is true
        firstLaunch = true

        // setting variables up
        energy = e.toFloat()
        length = l.toFloat()
        random = Random(seed)
        vx = FloatArray(this.numberOfParticles)
        vy = FloatArray(this.numberOfParticles)

        // setting color up, in run method we can colorize particles

//        ox = random!!.nextFloat() * mx/2 + mx/4
//        oy = random!!.nextFloat() * my/2 + my/4

        // setting particles up inside of vx and vy arrays,
        // each index represents each particle

        for ( i in 0 until this.numberOfParticles) {
            vx[i] = (random!!.nextFloat() + random!!.nextFloat()/2) * energy - energy/(random!!.nextInt(2) + 1)
            vy[i] = (random!!.nextFloat() + random!!.nextFloat()/2) * energy * 7/8 - energy/(random!!.nextInt(5) + 4)
        }

    }

    fun start() {
        t = 0f
        sleep = false
    }

    /**
     * Main method to run particles
     * @param canvas - field, where particles will move
     * @param paint - kind of pen, wchich draw particles on canvas
     */
    fun doDraw(canvas: Canvas?, paint: Paint) {
        if (!sleep) {
            if (t < length) {


                    // we cannot use mediaPlayer.start(), because we used async mode before
                    mediaPlayer.setOnPreparedListener { it.start() }

                // DO NOT DELETE COMMENTS OVER HERE
                // TODO: USE COMMENTS HERE TO CREATE MORE COLORFUL PARTICLES
                var i: Int
                val cr: Int
                val cg: Int
                val cb: Int
                var s: Double

                var _red = red
                var _green = green
                var _blue = blue

                if (bigBoom) {
                    cr = (random!!.nextDouble() * 64).toInt() - 32 + red
                    cg = (random!!.nextDouble() * 64).toInt() - 32 + green
                    cb = (random!!.nextDouble() * 64).toInt() - 32 + blue

                    if (cr >= 0 && cr <= 256) red = cr
                    if (cg >= 0 && cg <= 256) green = cg
                    if (cb >= 0 && cb <= 256) blue = cb

                    _red = if (red == 256) 255 else red
                    _green = if (green == 256) 255 else green
                    _blue = if (blue == 256) 255 else blue
                }

                // setting color up
                val color = Color.rgb(_red, _green, _blue)
                paint.color = color

                // particles' movement
                i = 0
                while (i < this.numberOfParticles) {
                    s = t.toDouble()/100
                    x = (vx[i] * s).toInt().toFloat()
                    y = (vy[i] * s - gravity * s * s).toInt().toFloat()
                   paint.alpha = max((255.0f - t*255.0f/length).toInt(), 1)
                    // drawing particles
                    canvas!!.drawCircle(ox + x, oy - y, 4f, paint)
                    ++i;
                }
//                Log.i("Particle", i.toString())
                // it is kind of movement tail of particle, not sure how to use it,
                // but it is very interesting
//                paint.color = Color.BLACK
//                i = 0
//                while ( i < this.numberOfParticles) {
//                    if ( t >= length/2) {
//                        for (j in 0..1) {
//                            s = ((t - length/2) * 2 + j ).toDouble()/100
//                            x = (vx[i] * s).toInt().toFloat()
//                            y = (vy[i] * s - gravity * s * s).toInt().toFloat()
//                            canvas!!.drawCircle(ox + x, oy - y, 2f, paint)
//                        }
//                    }
//                    ++i
//                }
                ++t
            }
            else firstLaunch=false
        }
    }




}

/**
 * Main class, which allow us to get fireworks together
 * @param width - screen width
 * @param height - screen height
 * @param context - to find assets in project structure
 */
internal class Fireworks(private var width: Int, private var height: Int, private var context: Context?) {

    // gravity strangth for particles
    var Gravity = 600
//    var mediaPlayer = MediaPlayer()

    // rockets array
    @Transient
    private var rocket = arrayListOf<Rocket>()

    /**
     * Increases Rockets amount in array
     */

    @Synchronized
    fun increaseFireworks(_x:Float, _y:Float, color: Int, size: Int, bigBoom: Boolean) {
        rocket.add(Rocket(width, height, Gravity, context, _x, _y, Color.red(color),Color.green(color),Color.blue(color),20+size, bigBoom))
    }


    /**
     * Change size of screen
     */
    @Synchronized
    fun reshape(width: Int, height: Int) {
        this.width = width
        this.height = height
    }

    /**
     * Draws every Rocket with particles
     * @param canvas - place to draw
     * @param paint - kind of pen to draw on the canvas
     */
    @Synchronized
    fun doDraw(canvas: Canvas?, paint: Paint) {
        // fill canvas black background
        canvas!!.drawColor(Color.BLACK)

        // TODO: rename variables
        // max rocket explosion energy picker
        var e: Int
        //max rocket life span picker
        var l: Int
        // ?
        var s: Long

        // when created then "move it, move it"
        if (rocket.size!=0) {


            // setting rockets up
           for(r in rocket) {
                e = 600
                l = 100
                s = (Math.random() * 10000).toLong()

                // prepare particle for run
                if (r.sleep) {
                    r.init(e, l, s, context)
                    r.start()
                }
                // run particle
                    r.doDraw(canvas, paint)
            }
        }
    }

    /**
     * Gives Max Rocket number
     */
    fun getAmount(): Int {
        return rocket.size
    }

    /**
     * Removes already finished fireworks from arraylist
     */
    @Synchronized
    fun clearFireworks() {
        var iterator = rocket.iterator()
        while (iterator.hasNext()) {
            if (!iterator.next().firstLaunch) {
                iterator.remove()
            }
        }
    }


}

/**
 * Responsible for animations activity with thread class
 */
class FireworkLayout @SuppressLint constructor(context: Context?) : SurfaceView(context), SurfaceHolder.Callback {

    /**
     * Main thread's class
     */
    internal inner class GameThread (private val surfaceHolder: SurfaceHolder,
                                     private val context: Context?,
                                     private val handler: Handler
    ): Thread() {

        private var mRun = false
        private var state: AnimateState? = null
        private val paint: Paint
        var fireworks: Fireworks
        lateinit var fileDesc: AssetFileDescriptor

        /**
         * Prepare thread to start
         */
        fun doStart() {
            synchronized(surfaceHolder) {
                setState(AnimateState.asRunning)
            }
        }

        /**
         * Prepare thread to stop
         */
        fun pause() {
            synchronized(surfaceHolder) {
                if (state == AnimateState.asRunning) setState(AnimateState.asPause)
            }
        }

        /**
         * Unpauses thread
         */
        fun unpause() {
            setState(AnimateState.asRunning)
        }

        /**
         * Runs thread, and starts drawing Fireworks
         */
        override fun run() {
            while (mRun) {
                var c: Canvas? = null
                try {
                    c = surfaceHolder.lockCanvas(null)
                    synchronized(surfaceHolder) {
                         if (state == AnimateState.asRunning) {
                             doDraw(c)
                             clearFireworks()
                         }
                    }
                }
                finally {
                    if (c != null) {
                        surfaceHolder.unlockCanvasAndPost(c)
                    }
                }

            }

        }

        private fun clearFireworks() {
            fireworks.clearFireworks()
        }

        /**
         * Sets runing to given state
         */
        fun setRunning(b: Boolean) {
            mRun = b
        }

        /**
         *
         */
        fun setState(state: AnimateState?) {
            synchronized(surfaceHolder) {
                this.state = state
            }
        }

        /**
         * Starts dwrawing fireworks
         */
        fun doDraw(canvas: Canvas?) {
            synchronized(surfaceHolder) {
                fireworks.doDraw(canvas, paint)
            }
        }

        /**
         * Gives fireworks amount generated at the same time
         * @return Fireworks
         */
        fun getFireworksAmount() {
            fireworks.getAmount()
        }

        /**
         * Sets field size, where fireworks show
         */
        fun setSurfaceSize(width: Int, height: Int) {
            synchronized(surfaceHolder) {
                fireworks.reshape(width, height)
            }
        }

        fun addFirework(_x: Float,_y: Float, color: Int, size: Int, bigBoom: Boolean) {
            synchronized(surfaceHolder) {
                fireworks.increaseFireworks(_x, _y, color,size, bigBoom)
            }
        }

        init {
            fireworks = Fireworks(width, height, context)
            paint = Paint()
            paint.strokeWidth = 2/resources.displayMetrics.density
            paint.color = Color.BLACK
            paint.isAntiAlias = false
        }

    }

    private val thread: GameThread
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        thread.setSurfaceSize(width, height)
    }

    override fun surfaceCreated(p0: SurfaceHolder) {
        thread.setRunning(true)
        thread.doStart()
        thread.start()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        var retry = true
        thread.setRunning(false)
        while (retry) {
            try {
                thread.join()
                retry = false
            }
            catch(e: InterruptedException) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Deprecated
     */
    fun onScreenTap(_x: Float, _y: Float) {
       // thread.addFirework(_x, _y)
    }

    fun displayFirework(xPos: Float, yPos: Float, color: Int,size: Int, bigBoom: Boolean) {
            thread.addFirework(xPos,yPos,color,size, bigBoom)
    }

    init {
        val holder = holder
        holder.addCallback(this)
        getHolder().addCallback(this)
        thread = GameThread(holder, context, object: Handler() {
            override fun handleMessage(msg: Message) {}
        })
        isFocusable = true
    }

}