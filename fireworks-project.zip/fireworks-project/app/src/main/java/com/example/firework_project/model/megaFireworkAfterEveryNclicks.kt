package com.example.firework_project.model

import android.graphics.Color


class megaFireworkAfterEveryNclicks(val everyNclicks: Int) : Model.onGlobalAction {
    override fun checkForAction(totalClicks: Int, view: Model.fView?) {
        if(totalClicks%everyNclicks==0) {
            view?.fire(Color.MAGENTA, 0.5, 0.5, 1500, true)
        }
    }
}