package com.example.calendar2

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.DateFormat
import java.text.ParseException
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.*


class SQLiteManager(context: Context?) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
//        val clearDBQuery = "DELETE FROM EventDB"
//        sqLiteDatabase.execSQL(clearDBQuery)
        val sql: StringBuilder
        sql = StringBuilder()
            .append("CREATE TABLE ")
            .append(TABLE_NAME)
            .append("(")
            .append(COUNTER)
            .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
            .append(ID_FIELD)
            .append(" INT, ")
            .append(NAME_FIELD)
            .append(" TEXT, ")
            .append(DATE_FIELD)
            .append(" DATE, ")
            .append(TIME_FIELD)
            .append(" TIME, ")
            .append(DELETED_FIELD)
            .append(" TEXT)")
        sqLiteDatabase.execSQL(sql.toString())
    }


    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
//        switch (oldVersion)
//        {
//            case 1:
//                sqLiteDatabase.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + NEW_COLUMN + " TEXT");
//            case 2:
//                sqLiteDatabase.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + NEW_COLUMN + " TEXT");
//        }
    }

    fun addEventToDatabase(event: Event) {
        val sqLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(ID_FIELD, event.id)
        contentValues.put(NAME_FIELD, event.name)
        contentValues.put(DATE_FIELD, event.date.toString())
        contentValues.put(TIME_FIELD, event.time.toString())
        contentValues.put(DELETED_FIELD, event.deleted)
        sqLiteDatabase.insert(TABLE_NAME, null, contentValues)
    }

    fun populateEventListArray() {
        val sqLiteDatabase = this.readableDatabase
        sqLiteDatabase.rawQuery("SELECT * FROM " + TABLE_NAME, null).use { result ->
            if (result.count != 0) {
                while (result.moveToNext()) {
                    val id = result.getInt(1)
                    val name = result.getString(2)
                    val stringdate = result.getString(3)
                    val time = result.getString(4)
                    val deleted = result.getString(5)
                    val event = Event(id, name, LocalDate.parse(stringdate) , LocalTime.parse(time), deleted.toBoolean())
                    //("id $id, name $name, date ${LocalDate.parse(stringdate)}, time ${LocalTime.parse(time)}, deleted $deleted")
                    Event.eventsList.add(event)
                }
            }
        }
    }

    fun updateNoteInDB(event: Event) {
        val sqLiteDatabase = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(ID_FIELD, event.id)
        contentValues.put(NAME_FIELD, event.name)
        contentValues.put(DATE_FIELD, event.date.toString())
        contentValues.put(TIME_FIELD, event.time.toString())
        contentValues.put(DELETED_FIELD, event.deleted)
        sqLiteDatabase.update(
            TABLE_NAME,
            contentValues,
            ID_FIELD + " =? ",
            arrayOf(java.lang.String.valueOf(event.id))
        )
    }

    private fun getStringFromDate(date: Date?): String? {
        return if (date == null) null else dateFormat.format(date)
    }


    private fun getDateFromString(string: String): Date? {
        return try {
            dateFormat.parse(string)
        } catch (e: ParseException) {
            null
        } catch (e: NullPointerException) {
            null
        }
    }

    fun convertToLocalDateViaInstant(dateToConvert: Date?): LocalDate? {
        return dateToConvert?.toInstant()
            ?.atZone(ZoneId.systemDefault())
            ?.toLocalDate()
    }

    companion object {
        private var sqLiteManager: SQLiteManager? = null
        private const val DATABASE_NAME = "EventDB"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "Note"
        private const val COUNTER = "Counter"
        private const val ID_FIELD = "id"
        private const val NAME_FIELD = "name"
        private const val DATE_FIELD = "date"
        private const val TIME_FIELD = "time"
        private const val DELETED_FIELD = "deleted"
        @SuppressLint("SimpleDateFormat")
        private val dateFormat: DateFormat = SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
        fun instanceOfDatabase(context: Context?): SQLiteManager? {
            if (sqLiteManager == null) sqLiteManager = SQLiteManager(context)
            return sqLiteManager
        }
    }
}

