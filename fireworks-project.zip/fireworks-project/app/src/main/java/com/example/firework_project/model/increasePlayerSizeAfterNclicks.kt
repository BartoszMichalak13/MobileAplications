package com.example.firework_project.model

class increasePlayerSizeAfterNclicks(val everyNclicks: Int) : Model.onPlayerClick {
    override fun checkForAction(player: Player, view: Model.fView?, yPos: Double, xPos: Double) {
        if(player.ClickCount%everyNclicks==0) {
            player.fireworkSize+=1
        }
    }
}