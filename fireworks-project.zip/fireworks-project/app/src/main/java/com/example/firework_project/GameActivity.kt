package com.example.firework_project

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.graphics.blue
import androidx.core.graphics.green
import androidx.core.graphics.red
import com.example.firework_project.model.Model
import com.example.firework_project.model.fireworkEveryFewClicksAction
import com.example.firework_project.model.increasePlayerSizeAfterNclicks
import com.example.firework_project.model.megaFireworkAfterEveryNclicks
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import vadiole.colorpicker.ColorModel
import vadiole.colorpicker.ColorPickerDialog


class GameActivity : AppCompatActivity(), Model.fView {
    var model = Model()
    var myID: Int = 0
    var width = 0.0f
    var height = 0.0f
    lateinit var firework: FireworkLayout

    val database = Firebase.database
    var playerRef: DatabaseReference? = null
    lateinit var roomName: String
    val TAG = "Gra"

    /**
     * SuppressLint allow to click on the screen and detect it.
     * Activity_main layout is the main game's layout.
     * */
    @SuppressLint("ClickableViewAccessibility", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        var prefernces: SharedPreferences = getSharedPreferences("PREFS",0)
        var playerName = prefernces.getString("playerName","").toString()
        Log.i(TAG, playerName)
        var playerColor = prefernces.getInt("playerColor",255)
        roomName = intent.extras?.getString("gameName")!!

        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        height = displayMetrics.heightPixels.toFloat()
        width = displayMetrics.widthPixels.toFloat()
        model.addAction(fireworkEveryFewClicksAction(3))
        model.addAction(increasePlayerSizeAfterNclicks(2))
        model.addGlobalAction(megaFireworkAfterEveryNclicks(10))
        myID = model.AddPlayer(Color.rgb(playerColor.red, playerColor.green,playerColor.blue))
        //CreateColorPickerDialog()
        model.setView(this)
        // FireworkLayout creates explosion animates
        firework = FireworkLayout(this)

        // Explosions are visible on "surface", which is stretched on all main screen
        val surface = findViewById<View>(R.id.surface) as LinearLayout
        surface.addView(firework)

        // It allow to detect screen's tap
        val mRelativeLayout = findViewById<ConstraintLayout>(R.id.layout)

        //TODO: TRZEBA ZAMIAST BARTOSZ BOHDZIEWICZ DAC NAZWE POKOJU W KTORYM JESTESMY
        val messageRef = database.getReference("Games/$roomName/message")

        messageRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val message = dataSnapshot.getValue(String::class.java)

                if (message != null) {
                    val parts = message.split(" ")
                    if (parts.size == 3) {
                        val xPos = parts[0].toDouble()
                        val yPos = parts[1].toDouble()
                        val playerId = parts[2].toInt()

                        //fire(playerColor, yPos*height, xPos*width, 1)

                        //TODO: OGARNAC ZEBY POBIERAC WARTOSC KOLORU
                        Log.i("KOLOR", playerId.toString())

                        model.playerClick(playerId,yPos,xPos)
                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "loadMessage:onCancelled", databaseError.toException())
            }
        })

        // When relative layout is tapped
        mRelativeLayout.setOnTouchListener { _, motionEvent ->

            if (motionEvent.action == MotionEvent.ACTION_DOWN) {
                print(motionEvent.x.toDouble()/width)
                print(motionEvent.y.toDouble()/height)

                val message = (motionEvent.x.toDouble()/width).toString()+" "+(motionEvent.y.toDouble()/height).toString()+" "+myID.toString()
                messageRef.setValue(message)
            }

            true
        }
    }

    override fun fire(color: Int, yPos: Double, xPos: Double, size: Int, bigBoom: Boolean) {

        firework.displayFirework(xPos.toFloat()*width, yPos.toFloat()*height,color,size, bigBoom)
    }
    override fun totalClickCountChanged(newTotal: Int) {
        //TODO: implement total click counter being viewed on screen
    }
}