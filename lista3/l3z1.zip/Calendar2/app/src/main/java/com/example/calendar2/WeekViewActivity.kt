package com.example.calendar2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.time.LocalDate


class WeekViewActivity : AppCompatActivity(), CalendarAdapter.OnItemListener {
    private lateinit var monthYearText: TextView
    private lateinit var calendarRecyclerView: RecyclerView
    private lateinit var eventListView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_week_view)
        initWidgets()

        setWeekView()
        setOnClickListener()

    }

    private fun setOnClickListener() {
        println("Im in set On Click Outer")

    eventListView.onItemClickListener = OnItemClickListener { adapterView, view, position, l ->
            println("Im in set On Click")
            val selectedEvent: Event = eventListView.getItemAtPosition(position) as Event
            val editEventIntent = Intent(this, EventEditActivity::class.java)
            editEventIntent.putExtra(Event.EVENT_EDIT_EXTRA, selectedEvent.id)
            println("id ${selectedEvent.id}")

            startActivity(editEventIntent)
        }
        println("Im in set On back")
    }

    fun setWeekView() :Unit {
        monthYearText.text = CalenderUtils.monthYearFromDate(CalenderUtils.selectedDate!!)
        var days: ArrayList<LocalDate?> =
            CalenderUtils.daysInWeekArray(CalenderUtils.selectedDate!!)
        var calendaradapter: CalendarAdapter = CalendarAdapter(days, this)
        var layoutManager: RecyclerView.LayoutManager = GridLayoutManager(applicationContext, 7)
        calendarRecyclerView.layoutManager = layoutManager
        calendarRecyclerView.adapter = calendaradapter
        setEventAdapter()
    }

    fun initWidgets() : Unit {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView)
        monthYearText = findViewById(R.id.monthYearTV)
        eventListView = findViewById(R.id.eventListView)
    }
    override fun onItemClick(position: Int, date: LocalDate?) {
        CalenderUtils.selectedDate = date
        setWeekView()
    }

    fun newEventAction(view: View) {
        val myintent = Intent(this, EventEditActivity::class.java)
        startActivity(myintent)
    }
    fun nextWeekAction(view: View) {
        CalenderUtils.selectedDate = CalenderUtils.selectedDate?.plusWeeks(1)
        setWeekView()
    }
    fun previousWeekAction(view: View) {
        CalenderUtils.selectedDate = CalenderUtils.selectedDate?.minusWeeks(1)
        setWeekView()
    }

    override fun onResume(){
        super.onResume()
        setEventAdapter()
    }
    fun setEventAdapter(): Unit{
        var dailyevents: ArrayList<Event>? = Event.eventsForDate(CalenderUtils.selectedDate)

        var eventAdapter: EventAdapter = EventAdapter(applicationContext, dailyevents)
        eventListView.adapter = eventAdapter

    }



}