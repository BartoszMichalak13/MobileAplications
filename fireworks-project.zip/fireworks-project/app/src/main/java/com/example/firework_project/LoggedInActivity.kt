package com.example.firework_project

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.graphics.blue
import androidx.core.graphics.green
import androidx.core.graphics.red
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.values
import com.google.firebase.ktx.Firebase
import vadiole.colorpicker.ColorModel
import vadiole.colorpicker.ColorPickerDialog

class LoggedInActivity : AppCompatActivity() {
    private var TAG = "ogienpraca-klikacz"
    private lateinit var auth: FirebaseAuth

    var color: Int = 0
    val database = Firebase.database
    var playerRef: DatabaseReference? = null

    var databesRef: DatabaseReference? = null

    var gameRef: DatabaseReference? = null
    lateinit var playerName: String
    lateinit var changeablePlayerName: String

    lateinit var gameName: String
    lateinit var email: String
    lateinit var editText: EditText

    //var FbUser = Firebase.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logged_in)
        auth = FirebaseAuth.getInstance()
        //var user: FirebaseUser? = auth.currentUser
        email = intent.getStringExtra("email")!!
        playerName = intent.getStringExtra("name")!!
        changeablePlayerName = playerName

        databesRef = database.getReference()

        editText = findViewById(R.id.editTextText)
        editText.setText(playerName)

//        var prefernces: SharedPreferences = getSharedPreferences("PREFS",0)
//        playerName = prefernces.getString("playerName","").toString()
        //check if player exists and get referene
        if(!playerName.equals("")){
            CreateColorPickerDialog()
        }

        findViewById<TextView>(R.id.textView).text = email + "\n" + playerName

        findViewById<Button>(R.id.btnSignOut).setOnClickListener{
            auth.signOut()
            startActivity(Intent(this, StartActivity::class.java))
        }
        Log.i(TAG, "test")

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            changeablePlayerName = editText.text.toString()
            playerRef = database.getReference("players/" + playerName + "/" + "playerName/")
            playerRef!!.setValue(changeablePlayerName)
            //writeNewPost(changeablePlayerName,color)
            //databesRef!!.child("players").child(playerName).setValue(changeablePlayerName)
            //changeablePlayerName = tmpplayerName
            //playerRef.child()
//            if (!playerName.equals("")) {
//                CreateColorPickerDialog()
//            }
        }
    }
    /////////////////////////////////////
//    private fun writeNewPost(playerName: String, color: Int) {
//        // Create new post at /user-posts/$userid/$postid and at
//        // /posts/$postid simultaneously
//        val key = database.reference.child("posts").key
//        if (key == null) {
//            Log.w(TAG, "Couldn't get push key for posts")
//            return
//        }
//
//        val post = User(playerName, color)
//        val postValues = post.toMap()
//
//        val childUpdates = hashMapOf<String, Any>(
//            "/posts/$key" to postValues,
//            "/user-posts/$playerName/$key" to postValues,
//        )
//
//        database.reference.updateChildren(childUpdates)
//    }


////////////////////////////////////////////////////////
    private fun addEvenetListener(){
        val postListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                //add player and play
                var prefernces: SharedPreferences = getSharedPreferences("PREFS", 0)
                var editor: SharedPreferences.Editor = prefernces.edit()
                if (!playerName.equals("")) {
                    Log.i(TAG, "playerName $playerName")

                    editor.putString("playerName", playerName)
                }
                Log.i(TAG, "color $color")
                editor.putInt("playerColor", color!!)

                Log.i(TAG, "editor $editor")
                editor.apply()

            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException())
            }
        }
        playerRef?.addValueEventListener(postListener)
    }
    private fun addGameEvenetListenerGames(){
        val postListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                //join game
                var myintent:Intent = Intent(applicationContext, GameActivity::class.java)
                myintent.putExtra("gameName", gameName)
                startActivity(myintent)
                finish()

            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadGame:onCancelled", databaseError.toException())
            }
        }
        gameRef?.addValueEventListener(postListener)
    }

    //THIS IS ONCLICK FUNCTION OF PICK COLOR BUTTON
    fun CreateColorPickerDialog() {
        val colorPicker: ColorPickerDialog = ColorPickerDialog.Builder()
            // Set initial (default) color
            .setInitialColor(Color.WHITE)
            // Set Color Model, can be ARGB, RGB, AHSV or HSV
            .setColorModel(ColorModel.RGB)
            // Set is user be able to switch color model
            .setColorModelSwitchEnabled(false)
            // Set your localized string resource for OK button
            .setButtonOkText(android.R.string.ok)
            // Set your localized string resource for Cancel button
            .setButtonCancelText(android.R.string.cancel)
            // Callback for picked color (required)
            .onColorSelected { color: Int ->
                //model.getPlayer(myID).Color = Color.rgb(color.red,color.green,color.blue)
                this.color = color
                if(!playerName.equals("")){
                    playerRef = database.getReference("players/" + playerName + "/" + "playerColor/")// + color )//("players/" + playerName)
                    addEvenetListener()
                    playerRef!!.setValue(color)
                    playerRef = database.getReference("players/" + playerName + "/" + "playerName/")
                    playerRef!!.setValue(changeablePlayerName)
                }
            }
            // Create dialog
            .create()
        // Show dialog from Activity
        colorPicker.show(supportFragmentManager, "color_picker")
    }

    fun joinClick(view: View) {
        startActivity(Intent(applicationContext, GameViewerActivity::class.java))
        finish()
    }
    fun createClick(view: View) {
        //create room and ad ur self as a player
        gameName = playerName
        gameRef = database.getReference("Games/" + gameName + "/"+playerName)
        //database.getReference("Games/" + gameName + "/message")
        addGameEvenetListenerGames()
        gameRef!!.setValue(changeablePlayerName)
        gameRef = database.getReference("Games/" + gameName + "/message")
        gameRef!!.setValue("EMPTY")
    }
}

