package com.example.firework_project

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class GameViewerActivity : AppCompatActivity() {

    lateinit var listView: ListView
    lateinit var gamesList: MutableList<String>
    var playerName = ""
    var gameName = ""
    var TAG = "ogienGra"

    val database = Firebase.database
    var playerRef: DatabaseReference? = null
    var gameRef: DatabaseReference? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_viewer)


        var preferences: SharedPreferences = getSharedPreferences("PREFS",0)
        playerName = preferences.getString("playerName", "").toString()
        gameName = playerName

        listView = findViewById(R.id.myListView)
        gamesList = mutableListOf()


        listView.setOnItemClickListener( AdapterView.OnItemClickListener { parent, view, position, id ->
            //join existing room
            gameName = gamesList[position]
            gameRef = database.getReference("Games/" + gameName + "/"+ playerName)
            addGameEvenetListenerGames()
            gameRef!!.setValue(playerName)
        } )

        addGamesEventListener()
    }
    private fun addGameEvenetListenerGames(){
        val postListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                //join game
                var myintent: Intent = Intent(applicationContext, GameActivity::class.java)
                myintent.putExtra("gameName", gameName)

                startActivity(myintent)
                finish()

            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadGame:onCancelled", databaseError.toException())
            }
        }
        gameRef?.addValueEventListener(postListener)
    }
    fun addGamesEventListener(){
        gameRef = database.getReference("Games")
        val postListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                //show lsit of rooms
                gamesList.clear()
                var games: Iterable<DataSnapshot> = dataSnapshot.children
                for(snapshot:DataSnapshot in games){
                    gamesList.add(snapshot.key.toString())//hopefully works

                    var adapter: ArrayAdapter<String> = ArrayAdapter(this@GameViewerActivity,
                        android.R.layout.simple_list_item_1, gamesList)
                    listView.adapter = adapter
                }


            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Getting Post failed, log a message
                Log.w(TAG, "loadGames:onCancelled", databaseError.toException())
            }
        }
        gameRef?.addValueEventListener(postListener)

    }
}