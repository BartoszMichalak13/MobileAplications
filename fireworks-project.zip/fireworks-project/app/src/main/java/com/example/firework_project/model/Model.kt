package com.example.firework_project.model


class Model {
    private var players = mutableMapOf<Int,Player>()
    private var actions: ArrayList<onPlayerClick> = ArrayList()
    private var globalActions: ArrayList<onGlobalAction> = ArrayList()
    /**
     * Returns player ID: Client thread will call function playerClick with this ID to report that some client send info about click
     */
    fun AddPlayer(color: Int): Int {
        players.put(color,Player(color))
        return color
    }


    /**
     * Returns number of total clicks performed by players
     */
    fun getTotalCount(): Int {
        var sum = 0
        for(p in players) {
            sum += p.value.ClickCount
        }
        return sum
    }

    /**
     * Function to report that player clicked. IMPORTANT: POSITION IS REPORTED AS PERCENT OF WIDTH/HEIGHT TO ADJUST TO DIFFERENT SCREEN SIZES
     */
    fun playerClick(playerID: Int, yPos: Double, xPos: Double) {
        if(!players.containsKey(playerID)){
            AddPlayer(playerID)
        }
        players[playerID]!!.ClickCount+=1
        for(action in actions) {
            action.checkForAction(players[playerID]!!,view,yPos,xPos)
        }
        val total = getTotalCount()
        for(global in globalActions) {
            global.checkForAction(total,view)
        }
        view?.totalClickCountChanged(getTotalCount())
    }


    private var view: fView? = null
    fun setView(view: fView?) {
        this.view = view
    }
    /**
     * fView views game state
     * for offline version just class that displays firework will implement it
     * for online version fView will be implement by class that will send info to every client
     */
    interface fView {
        /**
         * fire - should display firework with given parameters
         */
        fun fire(color: Int, yPos: Double, xPos: Double, size: Int, bigBoom: Boolean);

        /**
         * Informs about total firework count changed
         */
        fun totalClickCountChanged(newTotal: Int);
    }

    /**
     * objects implementing this interface are responsible for doing some actions on some condition
     * e.g. if player.ClickCount%3==0 view?.fire(player.color,yPos,xPos,player.size) if we want to implement "firework every three clicks for each player" mechanics
     */
    interface onPlayerClick {
        /**
         * called when player clicked
         */
        fun checkForAction(player: Player, view: fView?,yPos: Double, xPos: Double)
    }

    interface onGlobalAction {
        /**
         * e.g. display mega firework after every 1000 clicks
         */
        fun checkForAction(totalClicks: Int, view: fView?)
    }

    fun addGlobalAction(action: onGlobalAction) {
        globalActions.add(action)
    }

    fun addAction(action: onPlayerClick) {
        actions.add(action)
    }
}