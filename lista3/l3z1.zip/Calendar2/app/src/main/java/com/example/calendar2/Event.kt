package com.example.calendar2

import java.time.LocalDate
import java.time.LocalTime

class Event(id: Int?, name: String?, date: LocalDate?, time: LocalTime?, deleted: Boolean?) {

    companion object {
        val EVENT_EDIT_EXTRA: String? = "eventEdit"
        var eventsList: ArrayList<Event> = ArrayList()

        fun eventsForDate(date: LocalDate?): ArrayList<Event>? {
            val events: ArrayList<Event> = ArrayList()
            for (event in eventsList) {
                if (event.date?.equals(date) == true && event.deleted != true) {
                    events.add(event)
                }
            }
            return events
        }
        fun getEventbyID(passedID: Int): Event? {
            for(event in eventsList){
                if(event.id == passedID){
                    return event
                }
            }
            return null
        }
    }
    var id: Int?
    var name: String?
    var date: LocalDate?
    var time: LocalTime?
    var deleted: Boolean?
    init{
        this.name = name
        this.date = date
        this.time = time
        this.deleted = deleted
        this.id = id
        println("ID $id")
        println("Name $name")
    }
}