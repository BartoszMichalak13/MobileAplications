package com.example.firework_project.model


class Player(var Color: Int) {
    var ClickCount: Int = 0
    var fireworkSize: Int = 1
}