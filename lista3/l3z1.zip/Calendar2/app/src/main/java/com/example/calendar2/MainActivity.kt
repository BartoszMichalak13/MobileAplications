package com.example.calendar2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.calendar2.CalenderUtils.Companion.daysInMonthArray
import com.example.calendar2.CalenderUtils.Companion.monthYearFromDate
import java.time.LocalDate


class MainActivity : AppCompatActivity(), CalendarAdapter.OnItemListener{
    private lateinit var monthYearText: TextView
    private lateinit var calendarRecyclerView: RecyclerView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initWidgets()
        CalenderUtils.selectedDate = LocalDate.now()
        setMonthView()
        loadFromDBToMemory()
    }


    private fun loadFromDBToMemory() {
        val sqLiteManager: SQLiteManager?  = SQLiteManager.instanceOfDatabase(this)
        sqLiteManager!!.populateEventListArray()
    }
    fun setMonthView() :Unit {
        monthYearText.text = monthYearFromDate(CalenderUtils.selectedDate!!)
        var daysInMonth: ArrayList<LocalDate?> = daysInMonthArray(CalenderUtils.selectedDate!!)
        var calendaradapter: CalendarAdapter = CalendarAdapter(daysInMonth, this)
        var layoutManager: RecyclerView.LayoutManager = GridLayoutManager(applicationContext, 7)
        calendarRecyclerView.layoutManager = layoutManager
        calendarRecyclerView.adapter = calendaradapter
    }

    fun initWidgets() : Unit {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView)
        monthYearText = findViewById(R.id.monthYearTV)
    }
    fun nextMonthAction(view: View) {
        CalenderUtils.selectedDate = CalenderUtils.selectedDate?.plusMonths(1)
        setMonthView()
    }
    fun previousMonthAction(view: View) {
        CalenderUtils.selectedDate = CalenderUtils.selectedDate?.minusMonths(1)
        setMonthView()
    }

    override fun onItemClick(position: Int, date: LocalDate?) {
        if(date != null) {
            CalenderUtils.selectedDate = date
            setMonthView()
        }
    }

    fun weeklyAction(view: View) {
        startActivity(Intent(this, WeekViewActivity::class.java))
    }
}